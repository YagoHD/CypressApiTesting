# JSON Server

Get a full fake REST API with zero coding in less than 30 seconds (seriously)

## How to use

```[bash]
docker-compose up
```

You can see the server running in `localhost:3000`

More information: <https://github.com/typicode/json-server>
